// Application for launch Company of Heroes

#include <iostream>
#include <sys/stat.h>
#include <fstream>
#include <string>
#include "configFile.h"


char gamepath[100];
using namespace std;
void configFile(void)
{
    int result;
    struct _stat buf;
    char filepath[20]="./COH_path.ini"; //应用当前路径下的 COH_path.ini
    result=_stat(filepath,&buf);

    if (result!=0)
    {
        switch(errno)
        {
            case ENOENT:
            {
                ofstream outfile; //创建ofstream类对象
                outfile.open(filepath); //作为输出文件打开，如果文件不存在将建立新文件
                cout << "Please input the path of COH: " << endl;

                //将用户输入内容传递至文件
                cin.getline(gamepath,100,'\n');
                outfile << gamepath << endl;
            }
        }
    }
    else
    {
        ifstream infile;
        infile.open(filepath);
        infile.getline(gamepath,100,'\n');
        cout << "The path of game: " << gamepath << "\nIf it's incorrect, please delete COH_path.ini and restart the application."<< endl;
    }

}
