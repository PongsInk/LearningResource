#include <iostream>
#include <string>
#include <windows.h>
#include "configFile.h"

int main()
{   using namespace std;

    int mod,flag=0;
    char var[100];

    //Mod var list
    char farEast[100]="-dev -unlock_all_missions -nomovies -mod Far_East_Mod",
         babaRosa[100]="-dev -unlock_all_missions -nomovies -mod Baba_Rosa",
         europeAtWar[100]="-dev -nomovies -mod Europe_At_War",
         monkeyMod[100]="-dev -nomovies -mod Monkeying_Mod";

    configFile();


    while (flag==0)
    {
        //Display the list of mods
        cout << "Welcome to COH Launcher by Cyber Pong!\n"
             << "Following are the mods:\n"
             << "1.Far East    2.Baba Rosa    3.Europe at War    4.Monkey Mod"
             << "Please input the number to start mod:"
             << endl;

        cin >> mod;

        //Choose one and start it
        switch (mod)
        {
            case 1:
                {
                    strcpy(var,farEast);
                    flag=-1;
                    break;
                }
            case 2:
                {
                    strcpy(var,babaRosa);
                    flag=-1;
                    break;
                }
            case 3:
                {
                    strcpy(var,europeAtWar);
                    flag=-1;
                    break;
                }
            case 4:
                {
                    strcpy(var,monkeyMod);
                    flag=-1;
                    break;
                }

            default:
                {
                    cout << "Input incorrect, please try again!" << endl;
                    break;
                }
        }



    }


    char exe[20]={"/RelicCOH.exe "};
    strcat(gamepath,exe);
    HINSTANCE result=ShellExecute(NULL,TEXT("open"),(LPCTSTR)gamepath,(LPCTSTR)var,NULL,SW_SHOWNORMAL);
    if((int)result<32) //如果执行成功，result的数值应当大于32
    {
        cout << "Unknown error, launching failed.";
    }
    else
    {
        cout << "Launching, please wait a moment!" << endl;
        cout << gamepath << endl;
    }
    
    system("pause");
}
