#ifndef _CONFIGFILE_H_
#define _CONFIGFILE_H_


void configFile(void);
extern char gamepath[];

#endif
