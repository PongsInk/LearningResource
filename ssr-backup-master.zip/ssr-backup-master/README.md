# ShadowsocksR Backups

## Server
* ShadowsocksR-manyuser.zip - Python服务端，2017年7月27日傍晚版本，不含Git库
* ShadowsocksR-Python.zip - Python服务端，2017年7月27日凌晨版本，包含完整Git库

## Client (Compiled Binary)
* ShadowsocksR-4.7.0-win.zip - C#客户端，4.7.0版本（个人编译）
* ShadowsocksR-4.6.1-win.7z - C#客户端，4.6.1版本（官方Release）
* ShadowsocksR-3.4.0.5.apk - Android客户端，3.4.0.5版本
* ShadowsocksX-NG.1.5.1.zip - macOS客户端，1.5.1版本

## Client (Source Code)
* ShadowsocksR-android-3.4.0.6.6-src.zip - Android客户端源码，3.4.0.6.6版本
* ShadowsocksR-csharp-4.7.0-src.zip - C#客户端源码，4.7.0版本
* ShadowsocksX-NG-src.zip - macOS客户端源码
